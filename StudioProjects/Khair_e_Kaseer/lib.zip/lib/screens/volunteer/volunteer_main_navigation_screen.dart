import 'package:flutter/material.dart';
import 'package:khair_e_kaseer/screens/volunteer/volunteer_dashboard_screen.dart';
import 'package:khair_e_kaseer/screens/common/account_screen.dart';
import 'package:khair_e_kaseer/services/fcm_client_service.dart';

class VolunteerMainNavigationScreen extends StatefulWidget {
  const VolunteerMainNavigationScreen({super.key});

  @override
  State<VolunteerMainNavigationScreen> createState() =>
      _VolunteerMainNavigationScreenState();
}

class _VolunteerMainNavigationScreenState
    extends State<VolunteerMainNavigationScreen> {
  int _currentIndex = 0;
  final Color primaryGreen = const Color(0xFF347A5C);

  final List<Widget> _screens = [
    const VolunteerDashboard(),
    const VolunteerMyTasksPlaceholder(),
    const VolunteerAlertsPlaceholder(),
    const AccountScreen(),
  ];

  @override
  void initState() {
    super.initState();
    _initializeFCM();
  }

  Future<void> _initializeFCM() async {
    try {
      await FCMClientService.saveTokenToDatabase();
      if (mounted) {
        FCMClientService.listenToForegroundMessages(context);
      }
    } catch (e) {
      debugPrint("Error initializing FCM in VolunteerMainNavigationScreen: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: _screens,
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        type: BottomNavigationBarType.fixed,
        selectedItemColor: primaryGreen,
        unselectedItemColor: Colors.grey,
        onTap: (index) => setState(() => _currentIndex = index),
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.dashboard_outlined),
            activeIcon: Icon(Icons.dashboard),
            label: "Dashboard",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.two_wheeler_outlined),
            activeIcon: Icon(Icons.two_wheeler),
            label: "My Tasks",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.notifications_none),
            activeIcon: Icon(Icons.notifications),
            label: "Alerts",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_outline),
            activeIcon: Icon(Icons.person),
            label: "Account",
          ),
        ],
      ),
    );
  }
}

class VolunteerMyTasksPlaceholder extends StatelessWidget {
  const VolunteerMyTasksPlaceholder({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("My Active Tasks"),
        backgroundColor: Colors.white,
        foregroundColor: const Color(0xFF347A5C),
        elevation: 0.5,
      ),
      body: const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.delivery_dining, size: 60, color: Colors.grey),
            SizedBox(height: 10),
            Text("No active rides or deliveries in progress",
                style: TextStyle(color: Colors.grey)),
          ],
        ),
      ),
    );
  }
}

class VolunteerAlertsPlaceholder extends StatelessWidget {
  const VolunteerAlertsPlaceholder({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Delivery Alerts"),
        backgroundColor: Colors.white,
        foregroundColor: const Color(0xFF347A5C),
        elevation: 0.5,
      ),
      body: const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.notifications_off_outlined, size: 60, color: Colors.grey),
            SizedBox(height: 10),
            Text("No new delivery alerts right now",
                style: TextStyle(color: Colors.grey)),
          ],
        ),
      ),
    );
  }
}