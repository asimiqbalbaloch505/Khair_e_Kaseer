import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:khair_e_kaseer/screens/volunteer/active_tracking_screen.dart';
import 'package:url_launcher/url_launcher.dart';

class PickupDetailsScreen extends StatefulWidget {
  final String orderId;
  final Map<String, dynamic> orderData;

  const PickupDetailsScreen({
    super.key,
    required this.orderId,
    required this.orderData
  });

  @override
  State<PickupDetailsScreen> createState() => _PickupDetailsScreenState();
}

class _PickupDetailsScreenState extends State<PickupDetailsScreen> {
  final Color primaryGreen = const Color(0xFF347A5C);
  final Color bgCream = const Color(0xFFFBFBF4);


  Future<void> _acceptAndProceed() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    try {

      await FirebaseFirestore.instance.collection('Orders').doc(widget.orderId).update({
        'status': 'Accepted',
        'volunteerId': user.uid,
        'riderName': 'Volunteer Partner',
        'riderVehicle': 'Bike',
        'acceptedAt': FieldValue.serverTimestamp(),
      });


      if (mounted) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ActiveTrackingScreen(
              stepTitle: "Step 1 : Pickup",
              destinationName: widget.orderData['foodName'] ?? "Donor Location",
              destinationAddress: "Pickup Point",
              isPickupMode: true,
              orderId: widget.orderId,
            ),
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error accepting order: $e")),
      );
    }
  }

  Future<void> _openMap() async {
    const String googleUrl = 'https://www.google.com/maps/search/?api=1&query=Islamabad';
    final Uri url = Uri.parse(googleUrl);

    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    final data = widget.orderData;

    return Scaffold(
      backgroundColor: bgCream,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text("Request Details",
            style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10)],
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: primaryGreen.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(Icons.storefront, color: primaryGreen, size: 30),
                  ),
                  const SizedBox(width: 15),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(data['foodName'] ?? "Food Item",
                            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                        const Text("Donor Location", style: TextStyle(color: Colors.grey)),
                      ],
                    ),
                  ),
                  IconButton(
                    style: IconButton.styleFrom(
                      backgroundColor: primaryGreen,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                    icon: const Icon(Icons.near_me, color: Colors.white),
                    onPressed: _openMap,
                  ),
                ],
              ),
            ),

            const SizedBox(height: 25),


            const Text("Route Details",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15),
              ),
              child: Column(
                children: [
                  _buildRouteStep(Icons.location_on, primaryGreen, "Pickup From", "Donor Point"),
                  Padding(
                    padding: const EdgeInsets.only(left: 11),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Container(width: 2, height: 25, color: Colors.grey.shade300),
                    ),
                  ),
                  _buildRouteStep(Icons.flag, Colors.orange, "Deliver To", "Beneficiary Point"),
                ],
              ),
            ),

            const SizedBox(height: 25),


            const Text("Food Description",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15),
              ),
              child: Column(
                children: [
                  _buildInfoRow("Food Item", data['foodName'] ?? "N/A"),
                  const Divider(),
                  _buildInfoRow("Quantity", "${data['portionsClaimed']} Packs"),
                  const Divider(),
                  _buildInfoRow("Status", data['status'] ?? "Pending"),
                ],
              ),
            ),

            const SizedBox(height: 20),


            Container(
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(
                color: Colors.orange.shade50,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.orange.shade200),
              ),
              child: Row(
                children: [
                  Icon(Icons.timer_outlined, color: Colors.orange.shade800),
                  const SizedBox(width: 10),
                  const Expanded(
                    child: Text(
                      "Note: Pickup must be completed within 20-30 minutes for food safety.",
                      style: TextStyle(color: Color(0xFFB45309), fontSize: 13),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 30),


            SizedBox(
              width: double.infinity,
              height: 55,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: primaryGreen,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: _acceptAndProceed,
                child: const Text("PROCEED TO PICKUP",
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRouteStep(IconData icon, Color color, String label, String address) {
    return Row(
      children: [
        Icon(icon, color: color, size: 22),
        const SizedBox(width: 15),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label, style: const TextStyle(color: Colors.grey, fontSize: 12)),
              Text(address, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: Colors.grey, fontSize: 15)),
          Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
        ],
      ),
    );
  }
}