import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:khair_e_kaseer/screens/email_verification_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({super.key});

  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final TextEditingController _firstNameController = TextEditingController();
  final TextEditingController _lastNameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController = TextEditingController();

  String? _selectedRole;
  final List<String> _roles = ['Donor', 'Beneficiary', 'Volunteer', 'NGO'];
  bool _isLoading = false;

  final Color primaryGreen = const Color(0xFF347A5C);
  final Color bgCream = const Color(0xFFFBFBF4);

  bool _isValidEmail(String email) {
    return RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(email);
  }

  Future<void> _registerUser() async {
    final email = _emailController.text.trim();
    final password = _passwordController.text.trim();

    if (email.isEmpty ||
        password.isEmpty ||
        _selectedRole == null ||
        _firstNameController.text.trim().isEmpty ||
        _phoneController.text.trim().isEmpty) {
      _showErrorSnackBar("Please fill all fields and select your Role.");
      return;
    }

    if (!_isValidEmail(email)) {
      _showErrorSnackBar("Please enter a valid email address.");
      return;
    }

    if (password != _confirmPasswordController.text.trim()) {
      _showErrorSnackBar("Passwords do not match!");
      return;
    }

    if (password.length < 6) {
      _showErrorSnackBar("Password must be at least 6 characters long.");
      return;
    }

    setState(() => _isLoading = true);

    try {
      // 1. Create User in Firebase Auth
      UserCredential userCredential = await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      User? user = userCredential.user;

      if (user != null) {
        try {
          final bool isDonor = _selectedRole?.toLowerCase() == 'donor';

          // 2. Save User Profile in Firestore
          await FirebaseFirestore.instance.collection('Users').doc(user.uid).set({
            "userId": user.uid,
            "firstName": _firstNameController.text.trim(),
            "lastName": _lastNameController.text.trim(),
            "email": email,
            "phone": _phoneController.text.trim(),
            "role": _selectedRole,
            "isVerified": isDonor,
            "verificationStatus": isDonor ? "approved" : "unsubmitted",
            "createdAt": DateTime.now().millisecondsSinceEpoch,
          });

          // 3. Send single Firebase Email Verification link
          await user.sendEmailVerification();
          final prefs = await SharedPreferences.getInstance();
          await prefs.setBool('is_awaiting_verification', true);
          await prefs.setString('unverified_email', email);

          if (mounted) {
            // Clear entire stack so user can't press back to registration form
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(
                builder: (context) => EmailVerificationScreen(email: email),
              ),
                  (route) => false,
            );
          }
        } catch (firestoreError) {
          await user.delete();
          _showErrorSnackBar("Failed to save profile. Please try signing up again.");
        }
      }
    } on FirebaseAuthException catch (e) {
      _showErrorSnackBar(e.message ?? "Authentication Failed");
    } catch (e) {
      _showErrorSnackBar("Error: ${e.toString()}");
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.redAccent),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgCream,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 25.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 20),
              IconButton(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.arrow_back, color: Colors.black, size: 30),
              ),
              const SizedBox(height: 20),
              const Text('Sign Up', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
              const Text('Sign up and start sharing meals today.', style: TextStyle(fontSize: 15, color: Colors.grey)),
              const SizedBox(height: 30),

              _buildLabel('First Name'),
              _buildTextField(controller: _firstNameController, hintText: 'First Name', icon: Icons.person_outline),
              const SizedBox(height: 15),

              _buildLabel('Last Name'),
              _buildTextField(controller: _lastNameController, hintText: 'Last Name', icon: Icons.person_outline),
              const SizedBox(height: 15),

              _buildLabel('Email'),
              _buildTextField(controller: _emailController, hintText: 'Your Email', icon: Icons.email_outlined, keyboardType: TextInputType.emailAddress),
              const SizedBox(height: 15),

              _buildLabel('Phone Number'),
              _buildTextField(controller: _phoneController, hintText: 'Phone Number', icon: Icons.phone_outlined, keyboardType: TextInputType.phone),
              const SizedBox(height: 15),

              _buildLabel('Select Your Role'),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  color: const Color(0xFFE0E0E0).withOpacity(0.5),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    value: _selectedRole,
                    hint: const Text("Choose Role", style: TextStyle(color: Colors.grey)),
                    isExpanded: true,
                    icon: Icon(Icons.keyboard_arrow_down, color: primaryGreen),
                    items: _roles.map((String role) {
                      return DropdownMenuItem<String>(value: role, child: Text(role));
                    }).toList(),
                    onChanged: (String? newValue) {
                      setState(() => _selectedRole = newValue);
                    },
                  ),
                ),
              ),
              const SizedBox(height: 15),

              _buildLabel('Password'),
              _buildTextField(controller: _passwordController, hintText: 'Your Password', isPassword: true, icon: Icons.lock_outline),
              const SizedBox(height: 15),

              _buildLabel('Confirm Password'),
              _buildTextField(controller: _confirmPasswordController, hintText: 'Confirm Password', isPassword: true, icon: Icons.lock_outline),

              const SizedBox(height: 40),

              SizedBox(
                width: double.infinity,
                height: 55,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _registerUser,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: primaryGreen,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: _isLoading
                      ? const CircularProgressIndicator(color: Colors.white)
                      : const Text('Register', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                ),
              ),
              const SizedBox(height: 25),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLabel(String label) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0, left: 4),
      child: Text(label, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String hintText,
    bool isPassword = false,
    required IconData icon,
    TextInputType keyboardType = TextInputType.text,
  }) {
    return Container(
      decoration: BoxDecoration(color: const Color(0xFFE0E0E0).withOpacity(0.5), borderRadius: BorderRadius.circular(12)),
      child: TextField(
        controller: controller,
        obscureText: isPassword,
        keyboardType: keyboardType,
        decoration: InputDecoration(
          hintText: hintText,
          prefixIcon: Icon(icon, color: Colors.grey),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 15),
        ),
      ),
    );
  }
}