import 'dart:convert';
import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:khair_e_kaseer/screens/beneficiary/beneficiary_rider_tracking_screen.dart';
import 'package:khair_e_kaseer/screens/beneficiary/beneficiary_self_pickup_tracking.dart';

class BeneficiaryFoodDetailsScreen extends StatefulWidget {
  const BeneficiaryFoodDetailsScreen({super.key, required this.foodId, required this.foodData});
  final String foodId;
  final Map<String, dynamic> foodData;

  @override
  State<BeneficiaryFoodDetailsScreen> createState() => _BeneficiaryFoodDetailsScreenState();
}

class _BeneficiaryFoodDetailsScreenState extends State<BeneficiaryFoodDetailsScreen> {
  final Color primaryGreen = const Color(0xFF347A5C);
  final Color bgCream = const Color(0xFFFBFBF4);
  int _selectedPortions = 1;
  String _fulfillmentType = 'Delivery';

  @override
  Widget build(BuildContext context) {
    bool isBulk = widget.foodData['isBulk'] == true || widget.foodData['donationType'] == 'bulk';
    int availablePortions = widget.foodData['remainingPortions'] ?? 1;
    int portionLimit = availablePortions > 5 ? 5 : availablePortions;

    String foodTitle = widget.foodData['foodTitle'] ?? widget.foodData['foodName'] ?? "Food Item";
    String quantitySubtitle = isBulk
        ? (widget.foodData['quantityDescription'] ?? "Bulk Quantity")
        : "Remaining: $availablePortions Portions";

    return Scaffold(
      backgroundColor: bgCream,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text("Request Details", style: TextStyle(color: Colors.black)),
        leading: const BackButton(color: Colors.black),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Card(
              margin: const EdgeInsets.all(20),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
              child: Padding(
                padding: const EdgeInsets.all(15.0),
                child: Row(
                  children: [
                    Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(color: Colors.grey.shade100, borderRadius: BorderRadius.circular(10)),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: (widget.foodData['foodImage'] != null && widget.foodData['foodImage'].toString().isNotEmpty)
                            ? Image.memory(base64Decode(widget.foodData['foodImage']), fit: BoxFit.cover)
                            : Icon(Icons.fastfood, size: 30, color: Colors.grey.shade400),
                      ),
                    ),
                    const SizedBox(width: 15),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(foodTitle, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                          Text(quantitySubtitle, style: const TextStyle(color: Colors.grey)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 25),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (!isBulk) ...[
                    const Text("Portions Required:", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 10),
                    Row(
                      children: List.generate(
                        portionLimit,
                            (index) => GestureDetector(
                          onTap: () => setState(() => _selectedPortions = index + 1),
                          child: Container(
                            margin: const EdgeInsets.only(right: 10),
                            padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                            decoration: BoxDecoration(
                              color: _selectedPortions == index + 1 ? primaryGreen : Colors.white,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: primaryGreen.withOpacity(0.3)),
                            ),
                            child: Text(
                              "${index + 1}",
                              style: TextStyle(
                                color: _selectedPortions == index + 1 ? Colors.white : Colors.black,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 30),
                  ],

                  const Text("How will you get it?", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 10),
                  _buildFulfillmentOption(context, 'Delivery', Icons.directions_bike),
                  const SizedBox(height: 10),
                  _buildFulfillmentOption(context, 'Pickup', Icons.front_hand_outlined),

                  const SizedBox(height: 40),

                  SizedBox(
                    width: double.infinity,
                    height: 55,
                    child: ElevatedButton(
                      onPressed: () async {
                        final user = FirebaseAuth.instance.currentUser;
                        if (user == null) return;

                        showDialog(
                          context: context,
                          barrierDismissible: false,
                          builder: (context) => const Center(child: CircularProgressIndicator()),
                        );

                        try {
                          DocumentSnapshot userDoc = await FirebaseFirestore.instance
                              .collection('Users')
                              .doc(user.uid)
                              .get();

                          String userRole = 'Beneficiary';
                          if (userDoc.exists && userDoc.data() != null) {
                            userRole = (userDoc.get('role') ?? 'Beneficiary').toString();
                          }

                          String orderDisplayCode = "KF-${Random().nextInt(9000) + 1000}";
                          String generatedOtp = (1000 + Random().nextInt(9000)).toString();

                          DocumentReference newOrderRef = FirebaseFirestore.instance.collection('Orders').doc();
                          String newOrderId = newOrderRef.id;

                          String resolvedDonorId = widget.foodData['donorId'] ??
                              widget.foodData['userId'] ??
                              widget.foodData['donorUid'] ??
                              '';

                          DocumentReference donationRef = FirebaseFirestore.instance.collection('Donations').doc(widget.foodId);

                          String normalizedFulfillment = _fulfillmentType == 'Pickup' ? 'Self Pickup' : 'Delivery';

                          if (isBulk) {
                            Map<String, dynamic> bulkClaimData = {
                              'status': 'Claimed',
                              'claimedBy': user.uid,
                              'beneficiaryId': user.uid,
                              'claimedByRole': userRole,
                              'otp': generatedOtp,
                              'claimOtp': generatedOtp,
                              'fulfillmentMethod': normalizedFulfillment,
                              'deliveryType': normalizedFulfillment,
                              'orderDocId': newOrderId,
                              'orderId': orderDisplayCode,
                              'claimedAt': DateTime.now().millisecondsSinceEpoch,
                            };

                            await donationRef.set(bulkClaimData, SetOptions(merge: true));

                            await newOrderRef.set({
                              'orderDocId': newOrderId,
                              'orderId': orderDisplayCode,
                              'donationId': widget.foodId,
                              'foodName': foodTitle,
                              'foodTitle': foodTitle,
                              'otp': generatedOtp,
                              'claimOtp': generatedOtp,
                              'beneficiaryId': user.uid,
                              'claimedBy': user.uid,
                              'claimedByRole': userRole,
                              'donorId': resolvedDonorId,
                              'deliveryType': normalizedFulfillment,
                              'fulfillmentMethod': normalizedFulfillment,
                              'status': 'Pending',
                              'timestamp': FieldValue.serverTimestamp(),
                              'portionsClaimed': widget.foodData['quantityDescription'] ?? 'Bulk Quantity',
                              'foodImage': widget.foodData['foodImage'],
                              'volunteerId': null,
                            });
                          } else {
                            await FirebaseFirestore.instance.runTransaction((transaction) async {
                              DocumentSnapshot postSnap = await transaction.get(donationRef);

                              int currentRemaining = postSnap.exists ? (postSnap['remainingPortions'] ?? 1) : 1;

                              if (currentRemaining >= _selectedPortions) {
                                int newRemaining = currentRemaining - _selectedPortions;
                                if (postSnap.exists) {
                                  transaction.update(postSnap.reference, {
                                    'remainingPortions': newRemaining,
                                    'status': newRemaining == 0 ? 'Claimed' : 'Available',
                                    'claimedBy': user.uid,
                                    'beneficiaryId': user.uid,
                                    'claimedByRole': userRole,
                                    'otp': generatedOtp,
                                    'claimOtp': generatedOtp,
                                    'fulfillmentMethod': normalizedFulfillment,
                                    'deliveryType': normalizedFulfillment,
                                    'orderDocId': newOrderId,
                                    'orderId': orderDisplayCode,
                                  });
                                }

                                transaction.set(newOrderRef, {
                                  'orderDocId': newOrderId,
                                  'donationId': widget.foodId,
                                  'orderId': orderDisplayCode,
                                  'otp': generatedOtp,
                                  'claimOtp': generatedOtp,
                                  'foodName': foodTitle,
                                  'foodTitle': foodTitle,
                                  'portionsClaimed': _selectedPortions,
                                  'beneficiaryId': user.uid,
                                  'claimedBy': user.uid,
                                  'claimedByRole': userRole,
                                  'donorId': resolvedDonorId,
                                  'deliveryType': normalizedFulfillment,
                                  'fulfillmentMethod': normalizedFulfillment,
                                  'status': 'Pending',
                                  'timestamp': FieldValue.serverTimestamp(),
                                  'foodImage': widget.foodData['foodImage'],
                                  'volunteerId': null,
                                });
                              } else {
                                throw "Not enough portions available!";
                              }
                            });
                          }

                          if (mounted) Navigator.pop(context);

                          if (normalizedFulfillment == 'Delivery') {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(builder: (context) => BeneficiaryRiderTrackingScreen(orderDocId: newOrderId)),
                            );
                          } else {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(builder: (context) => BeneficiarySelfPickupTrackingScreen(orderDocId: newOrderId)),
                            );
                          }

                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text("Request Placed Successfully!"), backgroundColor: Colors.green),
                          );
                        } catch (e) {
                          if (mounted) Navigator.pop(context);
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text("Error: $e"), backgroundColor: Colors.red),
                          );
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: primaryGreen,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      child: const Text("REQUEST FOOD", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFulfillmentOption(BuildContext context, String type, IconData icon) {
    return GestureDetector(
      onTap: () => setState(() => _fulfillmentType = type),
      child: Container(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _fulfillmentType == type ? primaryGreen : Colors.transparent, width: 2),
        ),
        child: Row(
          children: [
            Icon(icon, color: primaryGreen),
            const SizedBox(width: 15),
            Text(type, style: const TextStyle(fontWeight: FontWeight.w500)),
            const Spacer(),
            Icon(_fulfillmentType == type ? Icons.radio_button_checked : Icons.radio_button_off, color: primaryGreen)
          ],
        ),
      ),
    );
  }
}