import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter/foundation.dart';

// Top-level background message handler (must be outside any class)
@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  debugPrint("Handling background message: ${message.messageId}");
}

class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  final FirebaseMessaging _fcm = FirebaseMessaging.instance;
  final FlutterLocalNotificationsPlugin _localNotifications = FlutterLocalNotificationsPlugin();

  Future<void> initialize() async {
    // 1. Register background handler
    FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

    // 2. Request notification permissions (iOS & Android 13+)
    NotificationSettings settings = await _fcm.requestPermission(
      alert: true,
      badge: true,
      sound: true,
      provisional: false,
    );

    if (settings.authorizationStatus == AuthorizationStatus.authorized) {
      debugPrint("User granted notification permission");
    } else {
      debugPrint("User declined or has not granted notification permission");
    }

    // 3. Setup Android Local Notification Channel for foreground banners
    const AndroidNotificationChannel channel = AndroidNotificationChannel(
      'khair_e_kaseer_channel', // id
      'High Priority Notifications', // title
      description: 'This channel is used for important app alerts.',
      importance: Importance.max,
    );

    const AndroidInitializationSettings initializationSettingsAndroid =
    AndroidInitializationSettings('@mipmap/ic_launcher');

    const InitializationSettings initializationSettings = InitializationSettings(
      android: initializationSettingsAndroid,
      iOS: DarwinInitializationSettings(),
    );

    await _localNotifications.initialize(initializationSettings);

    await _localNotifications
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);

    // 4. Handle foreground notifications (when app is open)
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      RemoteNotification? notification = message.notification;
      AndroidNotification? android = message.notification?.android;

      if (notification != null && android != null) {
        _localNotifications.show(
          notification.hashCode,
          notification.title,
          notification.body,
          NotificationDetails(
            android: AndroidNotificationDetails(
              channel.id,
              channel.name,
              channelDescription: channel.description,
              icon: android.smallIcon ?? '@mipmap/ic_launcher',
              importance: Importance.max,
              priority: Priority.high,
            ),
          ),
        );
      }
    });

    // 5. Save FCM Token if user is logged in
    await saveDeviceToken();

    // 6. Listen for token refreshes
    _fcm.onTokenRefresh.listen((newToken) async {
      await _updateTokenInFirestore(newToken);
    });
  }

  // Save/Update FCM Token in Firestore
  Future<void> saveDeviceToken() async {
    User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      String? token = await _fcm.getToken();
      if (token != null) {
        await _updateTokenInFirestore(token);
      }
    }
  }

  Future<void> _updateTokenInFirestore(String token) async {
    User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      try {
        await FirebaseFirestore.instance.collection('Users').doc(user.uid).set(
          {
            'fcmToken': token,
            'fcmTokenLastUpdated': FieldValue.serverTimestamp(),
          },
          SetOptions(merge: true),
        );
        debugPrint("FCM Token saved successfully for user ${user.uid}");
      } catch (e) {
        debugPrint("Error saving FCM Token: $e");
      }
    }
  }

  // ==========================================
  // PHASE 2: TOPIC SUBSCRIPTION & CLEANUP
  // ==========================================

  /// Subscribes current device to FCM topics based on role and vehicle type.
  Future<void> subscribeToRoleTopics({
    required String role,
    String? vehicleType,
  }) async {
    // Unsubscribe from existing topics first to prevent duplicate/stale subscriptions
    await unsubscribeFromAllTopics();

    String normalizedRole = role.trim().toLowerCase();

    switch (normalizedRole) {
      case 'donor':
        await _fcm.subscribeToTopic('topic_donor');
        debugPrint("Subscribed to topic_donor");
        break;

      case 'ngo':
        await _fcm.subscribeToTopic('topic_ngo');
        debugPrint("Subscribed to topic_ngo");
        break;

      case 'beneficiary':
        await _fcm.subscribeToTopic('topic_beneficiary');
        debugPrint("Subscribed to topic_beneficiary");
        break;

      case 'volunteer':
        if (vehicleType != null && vehicleType.isNotEmpty) {
          String normalizedVehicle = vehicleType.trim().toLowerCase();
          if (normalizedVehicle == 'van' || normalizedVehicle == 'truck') {
            await _fcm.subscribeToTopic('topic_volunteer_heavy');
            debugPrint("Subscribed to topic_volunteer_heavy");
          } else if (normalizedVehicle == 'bike' || normalizedVehicle == 'car') {
            await _fcm.subscribeToTopic('topic_volunteer_light');
            debugPrint("Subscribed to topic_volunteer_light");
          }
        }
        break;

      default:
        debugPrint("No matching notification topic for role: $role");
        break;
    }
  }

  /// Automatically fetches user data from Firestore and subscribes to matching topics.
  Future<void> setupUserSubscriptions() async {
    User? user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    try {
      DocumentSnapshot userDoc = await FirebaseFirestore.instance
          .collection('Users')
          .doc(user.uid)
          .get();

      if (userDoc.exists && userDoc.data() != null) {
        Map<String, dynamic> data = userDoc.data() as Map<String, dynamic>;
        String role = data['role'] ?? '';
        String? vehicleType = data['vehicleType'];

        await subscribeToRoleTopics(role: role, vehicleType: vehicleType);
      }
    } catch (e) {
      debugPrint("Error setting up user topic subscriptions: $e");
    }
  }

  /// Cleanly unsubscribes from all role topics upon logout.
  Future<void> unsubscribeFromAllTopics() async {
    try {
      await _fcm.unsubscribeFromTopic('topic_donor');
      await _fcm.unsubscribeFromTopic('topic_ngo');
      await _fcm.unsubscribeFromTopic('topic_beneficiary');
      await _fcm.unsubscribeFromTopic('topic_volunteer_heavy');
      await _fcm.unsubscribeFromTopic('topic_volunteer_light');
      debugPrint("Unsubscribed from all role topics");
    } catch (e) {
      debugPrint("Error unsubscribing from topics: $e");
    }
  }
}